package com.hexaware.dto;
import jakarta.validation.constraints.Min;
//deposit and withdraw dto
import jakarta.validation.constraints.NotNull;

public class TransactionDepositDTO {
	@NotNull
    @Min(value=500,message = " Amount must be greater than 500")
	private double transactionAmount;

	public TransactionDepositDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TransactionDepositDTO(double transactionAmount) {
		super();
		this.transactionAmount = transactionAmount;
	}

	public double getTransactionAmount() {
		return transactionAmount;
	}

	public void setTransactionAmount(double transactionAmount) {
		this.transactionAmount = transactionAmount;
	}

	@Override
	public String toString() {
		return "TransactionDepositDTO [transactionAmount=" + transactionAmount + "]";
	}
	

}
