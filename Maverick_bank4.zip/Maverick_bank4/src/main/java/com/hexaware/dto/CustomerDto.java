package com.hexaware.dto;
//Customer details add dto
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.List;

import com.hexaware.entity.Account;
import com.hexaware.enums.Gender;

import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Past;
import jakarta.validation.constraints.Pattern;

public class CustomerDto {
	private long customerId;
	@NotEmpty(message="Customer name cannot be empty")
	private String customerName;
	private Gender gender;
	@Pattern(regexp = "^\\d{10}$", message = "Invalid phone number. Phone number must be 10 digits")
	//@Max(value=10,message="Enter the number without +91")
	private String phoneNumber;
	@Pattern(regexp = "[A-Z]{5}[0-9]{4}[A-Z]{1}", message = "Invalid PAN card number. All letters should be capital")
	private String panNumber;
	//@Digits(integer = 12, fraction = 0, message = "Invalid Aadhar number")
	@Pattern(regexp = "^[2-9]{1}[0-9]{3}[0-9]{4}[0-9]{4}$", message = "Invalid Aadhar number.It should be 12 digits")
	private String aadharNumber;
	 @Email(message="Invalid Email")
	private String email;
	private String address;
	@Past
	private LocalDate dateOfBirth;
	@Min(value=18,message="Age must be atleast 18")
    private long age;
	//private List<Account> accountList=new ArrayList<>();
	public CustomerDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	public CustomerDto(long customerId, String customerName, Gender gender, String phoneNumber, String panNumber,
			String aadharNumber, String email, String address, LocalDate dateOfBirth, long age) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.gender = gender;
		this.phoneNumber = phoneNumber;
		this.panNumber = panNumber;
		this.aadharNumber = aadharNumber;
		this.email = email;
		this.address = address;

		this.dateOfBirth = dateOfBirth;
		this.age = age;
		//this.accountList = accountList;
	}
	public long getCustomerId() {
		return customerId;
	}
	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public Gender getGender() {
		return gender;
	}
	public void setGender(Gender gender) {
		this.gender = gender;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getPanNumber() {
		return panNumber;
	}
	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}
	public String getAadharNumber() {
		return aadharNumber;
	}
	public void setAadharNumber(String aadharNumber) {
		this.aadharNumber = aadharNumber;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}

	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
		updateAge();
	}
	public long getAge() {
		return age;
	}
	  private void updateAge() {
          LocalDate currentDate = LocalDate.now();
          this.age = Period.between(dateOfBirth, currentDate).getYears();
  }
	
//	public List<Account> getAccountList() {
//		return accountList;
//	}
//	public void setAccountList(List<Account> accountList) {
//		this.accountList = accountList;
//	}
	@Override
	public String toString() {
		return "CustomerDto [customerId=" + customerId + ", customerName=" + customerName + ", gender=" + gender
				+ ", phoneNumber=" + phoneNumber + ", panNumber=" + panNumber + ", aadharNumber=" + aadharNumber
				+ ", email=" + email + ", address=" + address + ", dateOfBirth="
				+ dateOfBirth + ", age=" + age + "]";
	}
	
	

}
