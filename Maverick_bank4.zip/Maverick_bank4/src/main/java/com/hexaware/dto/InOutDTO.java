package com.hexaware.dto;
//In bound and out bound dto
import java.time.LocalDate;

import com.hexaware.enums.TransactionType;

public class InOutDTO {
	private double totalInBound;
	private double totalOutBound;
	private double loan;
	public InOutDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public InOutDTO(double totalInBound, double totalOutBound, double loan) {
		super();
		this.totalInBound = totalInBound;
		this.totalOutBound = totalOutBound;
		this.loan = loan;
	}

	public double getTotalInBound() {
		return totalInBound;
	}
	public void setTotalInBound(double totalInBound) {
		this.totalInBound = totalInBound;
	}
	public double getTotalOutBound() {
		return totalOutBound;
	}
	public void setTotalOutBound(double totalOutBound) {
		this.totalOutBound = totalOutBound;
	}
	
	public double getLoan() {
		return loan;
	}

	public void setLoan(double loan) {
		this.loan = loan;
	}

	@Override
	public String toString() {
		return "InOutDTO [totalInBound=" + totalInBound + ", totalOutBound=" + totalOutBound + ", loan=" + loan + "]";
	}
	
	
}
	