package com.hexaware.dto;
//Add bankemployee details
import java.time.LocalDate;
import java.time.Period;

import com.hexaware.enums.AccountStatus;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Past;
import jakarta.validation.constraints.Pattern;

public class BankEmployeeAddDTO {
	private long employeeId;
	@NotEmpty
	private String employeeName;
	@Min(value=21,message="Age must be atleast 21")
	private int age;
	@Past
	private LocalDate dateOfBirth;
	private String address;
	@Pattern(regexp = "^\\d{10}$", message = "Invalid phone number. Phone number must be 10 digits")
	private String phoneNumber;
	@Pattern(regexp = "[A-Z]{5}[0-9]{4}[A-Z]{1}", message = "Invalid PAN card number. All letters should be capital")
	private String panCardNumber;
	private AccountStatus employeeStatus;
	private String email;
	public BankEmployeeAddDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public BankEmployeeAddDTO(long employeeId, String employeeName, int age, LocalDate dateOfBirth, String address,
			String phoneNumber, String panCardNumber, AccountStatus employeeStatus,String email) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.age = age;
		this.dateOfBirth = dateOfBirth;
		this.address = address;
		this.phoneNumber = phoneNumber;
		this.panCardNumber = panCardNumber;
		this.employeeStatus = employeeStatus;
		this.email=email;
	}
	public long getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(long employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
		updateAge();
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getPanCardNumber() {
		return panCardNumber;
	}
	public void setPanCardNumber(String panCardNumber) {
		this.panCardNumber = panCardNumber;
	}
	public AccountStatus getEmployeeStatus() {
		return employeeStatus;
	}
	public void setEmployeeStatus(AccountStatus employeeStatus) {
		this.employeeStatus = employeeStatus;
	}
	private void updateAge() {
        LocalDate currentDate = LocalDate.now();
        this.age = Period.between(dateOfBirth, currentDate).getYears();
}
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Override
	public String toString() {
		return "BankEmployeeAddDTO [employeeId=" + employeeId + ", employeeName=" + employeeName + ", age=" + age
				+ ", dateOfBirth=" + dateOfBirth + ", address=" + address + ", phoneNumber=" + phoneNumber
				+ ", panCardNumber=" + panCardNumber + ", employeeStatus=" + employeeStatus + ", email=" + email + "]";
	}
	


}
