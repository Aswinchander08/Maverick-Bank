package com.hexaware.dto;
//add other bank details by employee
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

public class OtherBankDetailsAddDTO {
	private long otherBankId;
	@NotNull
	private String otherBankName;
	@NotNull
	private String otherBankBranch;
	 @NotNull
	 @Pattern(regexp = "^[A-Z]{4}[0-9]{4}$", message = "Invalid IFSC code. Four capital letters and four digits")
	private String otherIFSCCode;
	 
	public OtherBankDetailsAddDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public OtherBankDetailsAddDTO(long otherBankId, @NotNull String otherBankName, @NotNull String otherBankBranch,
			@NotNull @Pattern(regexp = "^[A-Z]{4}[0-9]{4}$", message = "Invalid IFSC code. Four capital letters and four digits") String otherIFSCCode) {
		super();
		this.otherBankId = otherBankId;
		this.otherBankName = otherBankName;
		this.otherBankBranch = otherBankBranch;
		this.otherIFSCCode = otherIFSCCode;
	}

	public long getOtherBankId() {
		return otherBankId;
	}

	public void setOtherBankId(long otherBankId) {
		this.otherBankId = otherBankId;
	}

	public String getOtherBankName() {
		return otherBankName;
	}

	public void setOtherBankName(String otherBankName) {
		this.otherBankName = otherBankName;
	}

	public String getOtherBankBranch() {
		return otherBankBranch;
	}

	public void setOtherBankBranch(String otherBankBranch) {
		this.otherBankBranch = otherBankBranch;
	}

	public String getOtherIFSCCode() {
		return otherIFSCCode;
	}

	public void setOtherIFSCCode(String otherIFSCCode) {
		this.otherIFSCCode = otherIFSCCode;
	}

	@Override
	public String toString() {
		return "OtherBankDetailsAddDTO [otherBankId=" + otherBankId + ", otherBankName=" + otherBankName
				+ ", otherBankBranch=" + otherBankBranch + ", otherIFSCCode=" + otherIFSCCode + "]";
	}
	

}
