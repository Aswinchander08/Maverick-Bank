package com.hexaware.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hexaware.customexceptions.LessBalanceException;
import com.hexaware.customexceptions.ResourceNotFoundException;
import com.hexaware.dto.AllTransactionDTO;
import com.hexaware.dto.TransactionDepositDTO;
import com.hexaware.dto.TransactionTransferDTO;
import com.hexaware.service.TransactionService;

import jakarta.validation.Valid;

@RestController
@CrossOrigin("*")
@RequestMapping("/api/bank/transaction")
public class TransactionController {

	@Autowired
	private TransactionService transactionService;
	@PreAuthorize("hasAuthority('ROLE_USER')")
	@PostMapping("/transfer/{accountnumber}")
	public ResponseEntity<String> transferAmount(@PathVariable long accountnumber,
			@Valid @RequestBody TransactionTransferDTO transaction) throws ResourceNotFoundException, LessBalanceException {
		return ResponseEntity.ok(transactionService.transferAmount(accountnumber, transaction));
	}
	@PreAuthorize("hasAuthority('ROLE_USER')")
	@PostMapping("/deposit/{accountnumber}")
	public ResponseEntity<String> depositAmount(@PathVariable long accountnumber,
			@Valid @RequestBody TransactionDepositDTO transaction) throws ResourceNotFoundException {
		return ResponseEntity.ok(transactionService.depositAmount(accountnumber, transaction));
	}
	@PreAuthorize("hasAuthority('ROLE_USER')")
	@PostMapping("/withdraw/{accountnumber}")
	public ResponseEntity<String> withdrawAmount(@PathVariable long accountnumber,
			@Valid @RequestBody TransactionDepositDTO transaction) throws ResourceNotFoundException, LessBalanceException {
		return ResponseEntity.ok(transactionService.withdrawAmount(accountnumber, transaction));
	}
	@GetMapping("/view10transaction/{accountnumber}")
	public ResponseEntity<List<AllTransactionDTO>>view10Transaction(@PathVariable long accountnumber)
	{
		return ResponseEntity.ok(transactionService.view10Transaction(accountnumber));
		
	}
	
	@GetMapping("/transactionbetween/{accountnumber}/{startdate}/{enddate}")
	public ResponseEntity<List<AllTransactionDTO>>TransactionBetweenTwoDates(@PathVariable long accountnumber, @PathVariable LocalDate startdate,
			@PathVariable LocalDate enddate)
	{
		return ResponseEntity.ok(transactionService.TransactionBetweenTwoDates(accountnumber, startdate, enddate));
		
	}
	
	@GetMapping("/transactionforlastmonth/{accountnumber}")
	public ResponseEntity<List<AllTransactionDTO>>TransactionForLastMonth(@PathVariable long accountnumber)
	{
		LocalDate startdate = LocalDate.now().minusMonths(1);
		return ResponseEntity.ok(transactionService.TransactionForLastMonth(accountnumber, startdate));
		
	}

}
