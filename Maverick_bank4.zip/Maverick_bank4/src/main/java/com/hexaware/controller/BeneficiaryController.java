package com.hexaware.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hexaware.customexceptions.ResourceNotFoundException;
import com.hexaware.dto.BeneficiaryAddDTO;
import com.hexaware.service.BeneficiaryService;

import jakarta.validation.Valid;

@RestController
@CrossOrigin("*")
@RequestMapping("/api/bank/beneficiary")
public class BeneficiaryController {
	
	@Autowired
	private BeneficiaryService beneficiaryService;
	
	@PostMapping("/{accountid}/{bankname}/{bankbranch}/{ifsc}")
	@PreAuthorize("hasAuthority('ROLE_USER')")
	public ResponseEntity<String> addBeneficiary(@PathVariable long accountid,@PathVariable String bankname,@PathVariable String bankbranch,@PathVariable String ifsc,@Valid @RequestBody BeneficiaryAddDTO beneficiary) throws ResourceNotFoundException
	{
		return ResponseEntity.ok(beneficiaryService.addBeneficiary(accountid, bankname, bankbranch, ifsc, beneficiary));
		
	}
	@GetMapping("/{accountnumber}")
	public ResponseEntity<List<BeneficiaryAddDTO>> getBeneficiary(@PathVariable long accountnumber) throws ResourceNotFoundException
	{
		return ResponseEntity.ok(beneficiaryService.getBeneficiary(accountnumber));
	}

}
