package com.hexaware.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hexaware.customexceptions.ResourceNotFoundException;
import com.hexaware.dto.BankEmployeeAddDTO;
import com.hexaware.entity.Bank;
import com.hexaware.service.BankEmployeeService;
import com.hexaware.service.BankService;

@RestController
@RequestMapping("/api/bank")
@CrossOrigin("*")
public class BankController {
	private BankService bankService;
	
	@Autowired
	private BankEmployeeService employeeService;

	public BankController(BankService bankService) {
		super();
		this.bankService = bankService;
	}
	@PostMapping("/addbank")
	public ResponseEntity<Bank> addBank(@RequestBody Bank bank)
	{
		return ResponseEntity.ok(bankService.addBank(bank));
	}
	@PreAuthorize("hasAuthority('ROLE_ADMIN')")
	@GetMapping("/viewallemployees")
	public ResponseEntity<List<BankEmployeeAddDTO>> displayAllEmployee()
	{
		return ResponseEntity.ok(employeeService.displayAllEmployee());
	}
	//This Service is in bankemployee service
	@PreAuthorize("hasAuthority('ROLE_ADMIN')")
	@DeleteMapping("/deleteemp/{empid}")
	public ResponseEntity<String> deleteEmployee(@PathVariable long empid) throws ResourceNotFoundException
	{
		return ResponseEntity.ok(employeeService.deleteEmployee(empid));
	}
	

}
