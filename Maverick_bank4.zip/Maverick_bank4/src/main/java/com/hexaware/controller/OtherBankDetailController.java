package com.hexaware.controller;




import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hexaware.dto.OtherBankDetailsAddDTO;
import com.hexaware.service.OtherBankDetailService;

import jakarta.validation.Valid;

@RestController
@CrossOrigin("*")
@RequestMapping("/api/otherbank")
public class OtherBankDetailController {
	private OtherBankDetailService otherService;

	public OtherBankDetailController(OtherBankDetailService otherService) {
		super();
		this.otherService = otherService;
	}
	
	@PostMapping("/addotherbank")
	public ResponseEntity<OtherBankDetailsAddDTO> addOtherBank(@Valid @RequestBody OtherBankDetailsAddDTO otherBank)
	{
		return ResponseEntity.ok(otherService.addOtherBank(otherBank));
	}
	
	@GetMapping("bankname/{name}")
	public ResponseEntity<List<String>> findByotherBankNameContaining(@PathVariable String name){
			return ResponseEntity.ok(otherService.findByotherBankNameContaining(name));	
		
	}
	@GetMapping("branch/{bankname}")
	public ResponseEntity<List<String>> findBankBranch(@PathVariable String bankname)
	{
		return ResponseEntity.ok(otherService.findBankBranch(bankname));
		
	}
	@GetMapping("/{bankname}/{branchname}")
	public ResponseEntity <String> getBankIfsccode(@PathVariable String bankname,@PathVariable String branchname)
	{
		return ResponseEntity.ok(otherService.getIfsccode(bankname,branchname));
		
	}
	
	

}
