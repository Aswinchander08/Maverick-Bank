package com.hexaware.entity;

import java.util.ArrayList;
import java.util.List;

import com.hexaware.enums.LoanStatus;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table
public class Loan {
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long loanID;
	private double loanAmount;
	private double interestRate;
	private double tenure;
	@Enumerated(EnumType.STRING)
	private LoanStatus loanStatus;
	private String loanName;
	
	@ManyToOne
	@JoinColumn(name="account_no")
	private Account account;
	
	
	@ManyToMany(mappedBy="loanList")
	private List<BankEmployee> employeeList=new ArrayList<>();
	
	public Loan() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Loan(long loanID, double loanAmount, double interestRate, double tenure, LoanStatus loanStatus,
			String loanName, Account account, List<BankEmployee> employeeList) {
		super();
		this.loanID = loanID;
		this.loanAmount = loanAmount;
		this.interestRate = interestRate;
		this.tenure = tenure;
		this.loanStatus = loanStatus;
		this.loanName = loanName;
		this.account = account;
		this.employeeList = employeeList;
	}

	public long getLoanID() {
		return loanID;
	}

	public void setLoanID(long loanID) {
		this.loanID = loanID;
	}

	public double getLoanAmount() {
		return loanAmount;
	}

	public void setLoanAmount(double loanAmount) {
		this.loanAmount = loanAmount;
	}

	public double getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(double interestRate) {
		this.interestRate = interestRate;
	}

	public double getTenure() {
		return tenure;
	}

	public void setTenure(double tenure) {
		this.tenure = tenure;
	}

	public LoanStatus getLoanStatus() {
		return loanStatus;
	}

	public void setLoanStatus(LoanStatus loanStatus) {
		this.loanStatus = loanStatus;
	}

	public String getLoanName() {
		return loanName;
	}

	public void setLoanName(String loanName) {
		this.loanName = loanName;
	}

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	public List<BankEmployee> getEmployeeList() {
		return employeeList;
	}

	public void setEmployeeList(List<BankEmployee> employeeList) {
		this.employeeList = employeeList;
	}

	@Override
	public String toString() {
		return "Loan [loanID=" + loanID + ", loanAmount=" + loanAmount + ", interestRate=" + interestRate + ", tenure="
				+ tenure + ", loanStatus=" + loanStatus + ", loanName=" + loanName + ", account=" + account
				+ ", employeeList=" + employeeList + "]";
	}
	

}
