package com.hexaware.entity;

import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.hexaware.enums.Gender;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="customers")
public class Customer {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long customerId;
	private String customerName;
	@Enumerated(EnumType.STRING)
	private Gender gender;
	private String phoneNumber;
	private String panNumber;
	private String aadharNumber;
	private String email;
	private String address;
	private LocalDate dateOfBirth;
    private long age;
    @OneToMany(cascade=CascadeType.ALL,orphanRemoval = true)
	@JoinTable(name="customer_account_mapping",joinColumns=@JoinColumn(name="customer_id"),inverseJoinColumns=@JoinColumn(name="account_id"))
	private List<Account> accountList=new ArrayList<>();
	
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}	
	
    // Additional method to update age based on date of birth
    private void updateAge() {
            LocalDate currentDate = LocalDate.now();
            this.age = Period.between(dateOfBirth, currentDate).getYears();
    }
	
	public long getAge() {
        return age;
    }

	public Customer(long customerId, String customerName, Gender gender, String phoneNumber, String panNumber,
			String aadharNumber, String email, String address,  LocalDate dateOfBirth,
			List<Account> accountList) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.gender = gender;
		this.phoneNumber = phoneNumber;
		this.panNumber = panNumber;
		this.aadharNumber = aadharNumber;
		this.email = email;
		this.address = address;
		this.dateOfBirth = dateOfBirth;
		this.accountList = accountList;
	}

	public long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public Gender getGender() {
		return gender;
	}

	public void setGender(Gender gender) {
		this.gender = gender;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getPanNumber() {
		return panNumber;
	}

	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}

	public String getAadharNumber() {
		return aadharNumber;
	}

	public void setAadharNumber(String aadharNumber) {
		this.aadharNumber = aadharNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}


	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(LocalDate dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
        updateAge();
    }
		
	public List<Account> getAccountList() {
		return accountList;
	}

	public void setAccountList(List<Account> accountList) {
		this.accountList = accountList;
	}
	public void addAccountList(Account account)
	{
		this.accountList.add(account);
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", gender=" + gender
				+ ", phoneNumber=" + phoneNumber + ", panNumber=" + panNumber + ", aadharNumber=" + aadharNumber
				+ ", email=" + email + ", address=" + address + ", dateOfBirth="
				+ dateOfBirth + ", age=" + age + ", accountList=" + accountList + "]";
	}
	

}
