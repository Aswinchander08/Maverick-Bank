package com.hexaware.entity;

import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.List;

import com.hexaware.enums.AccountStatus;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table
public class BankEmployee {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long employeeId;
	private String employeeName;
	private int age;
	private LocalDate dateOfBirth;
	private String address;
	private String phoneNumber;
	private String panCardNumber;
	private String email;
	@Enumerated(EnumType.STRING)
	private AccountStatus employeeStatus;
	
	@ManyToMany(mappedBy="bankEmployee",cascade=CascadeType.ALL)
	private List<Account> accountList=new ArrayList<>();
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="'bank_id")
	private Bank bank;
	
	@ManyToMany(cascade=CascadeType.ALL)
	@JoinTable(name="employee_loan_mapping",joinColumns=@JoinColumn(name="employee_id"),inverseJoinColumns=@JoinColumn(name="loan_id"))
	private List<Loan> loanList=new ArrayList<>();
	
	@ManyToMany(cascade=CascadeType.ALL)
	@JoinTable(name="employee_transaction_mapping",joinColumns=@JoinColumn(name="employee_id"),inverseJoinColumns=@JoinColumn(name="transaction_id"))
	private List<Transaction> transactionList=new ArrayList<>();

	
	
	public BankEmployee(long employeeId, String employeeName, int age, LocalDate dateOfBirth, String address,
			String phoneNumber, String panCardNumber,String email, AccountStatus employeeStatus, List<Account> accountList, Bank bank,
			List<Loan> loanList, List<Transaction> transactionList) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.age = age;
		this.dateOfBirth = dateOfBirth;
		this.address = address;
		this.phoneNumber = phoneNumber;
		this.panCardNumber = panCardNumber;
		this.email=email;
		this.employeeStatus = employeeStatus;
		this.accountList = accountList;
		this.bank = bank;
		this.loanList = loanList;
		this.transactionList = transactionList;
	}

	public BankEmployee() {
		super();
		// TODO Auto-generated constructor stub
	}
	

	public long getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(long employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getPanCardNumber() {
		return panCardNumber;
	}

	public void setPanCardNumber(String panCardNumber) {
		this.panCardNumber = panCardNumber;
	}

	public AccountStatus getEmployeeStatus() {
		return employeeStatus;
	}

	public void setEmployeeStatus(AccountStatus employeeStatus) {
		this.employeeStatus = employeeStatus;
	}

	public List<Account> getAccountList() {
		return accountList;
	}

	public void setAccountList(List<Account> accountList) {
		this.accountList = accountList;
	}

	public Bank getBank() {
		return bank;
	}

	public void setBank(Bank bank) {
		this.bank = bank;
	}

	public List<Loan> getLoanList() {
		return loanList;
	}

	public void setLoanList(List<Loan> loanList) {
		this.loanList = loanList;
	}

	public List<Transaction> getTransactionList() {
		return transactionList;
	}

	public void setTransactionList(List<Transaction> transactionList) {
		this.transactionList = transactionList;
	}

	public int getAge() {
		return age;
	}

	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
		updateAge();
		
	}
	 private void updateAge() {
	            LocalDate currentDate = LocalDate.now();
	            this.age = Period.between(dateOfBirth, currentDate).getYears();
	    }
	 

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "BankEmployee [employeeId=" + employeeId + ", employeeName=" + employeeName + ", age=" + age
				+ ", dateOfBirth=" + dateOfBirth + ", address=" + address + ", phoneNumber=" + phoneNumber
				+ ", panCardNumber=" + panCardNumber + ", email=" + email + ", employeeStatus=" + employeeStatus
				+ ", accountList=" + accountList + ", bank=" + bank + ", loanList=" + loanList + ", transactionList="
				+ transactionList + "]";
	}

	
	 
	


}
