package com.hexaware.enums;

public enum TransactionType {
	DEPOSIT("DEPOSIT"),
	WITHDRAW("WITHDRAW"),
	TRANSFER("TRANSFER"),
	LOAN("LOAN");
private  String type;
	
	TransactionType(String string) {
		// TODO Auto-generated constructor stub
		this.type=string;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}

}
