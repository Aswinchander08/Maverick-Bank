package com.hexaware.enums;

public enum Gender {
	Male,Female,Other

}
