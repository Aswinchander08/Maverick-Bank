package com.hexaware.enums;

public enum LoanStatus {
	APPLIED,APPROVED,REJECTED

}
