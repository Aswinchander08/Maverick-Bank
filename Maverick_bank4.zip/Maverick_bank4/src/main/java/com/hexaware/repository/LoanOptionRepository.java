package com.hexaware.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hexaware.entity.LoanOption;

public interface LoanOptionRepository extends JpaRepository<LoanOption,Long>{

}
