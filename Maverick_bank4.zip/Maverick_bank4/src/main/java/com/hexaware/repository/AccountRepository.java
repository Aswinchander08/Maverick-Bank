package com.hexaware.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hexaware.entity.Account;

public interface AccountRepository extends JpaRepository<Account,Long>{
	@Query(value="INSERT INTO accounts VALUES(?,?,?,?,?)",nativeQuery = true)
	Account addaccount(Account account);
	@Query(value="SELECT * FROM accounts a WHERE a.customer_customer_id=:customer_id",nativeQuery = true)
	List<Account>findAllAccountsOfCustomer(long customer_id);
	


}
