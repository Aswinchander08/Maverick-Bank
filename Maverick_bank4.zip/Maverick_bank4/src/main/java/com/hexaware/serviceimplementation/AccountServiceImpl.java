package com.hexaware.serviceimplementation;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hexaware.customexceptions.ResourceNotFoundException;
import com.hexaware.dto.AccountDetailsDTO;
import com.hexaware.dto.AccountDisplayDTO;
import com.hexaware.dto.AccountRequestDTO;
import com.hexaware.dto.LoanDTO;
import com.hexaware.dto.LoanResponseDTO;
import com.hexaware.entity.Account;
import com.hexaware.entity.Bank;
import com.hexaware.entity.Customer;
import com.hexaware.entity.Loan;
import com.hexaware.enums.AccountStatus;
import com.hexaware.enums.LoanStatus;
import com.hexaware.repository.AccountRepository;
import com.hexaware.repository.BankRepository;
import com.hexaware.repository.CustomerRepository;
import com.hexaware.repository.LoanRepository;
import com.hexaware.repository.TransactionRepository;
import com.hexaware.service.AccountService;

@Service
public class AccountServiceImpl implements AccountService {

	private AccountRepository accountRepo;
	@Autowired
	private CustomerRepository customerRepo;
	@Autowired
	private ModelMapper modelMapper;
	@Autowired
	private BankRepository bankRepo;
	@Autowired
	private LoanRepository loanRepo;
	@Autowired
	private TransactionRepository transactionRepo;

	public AccountServiceImpl(AccountRepository accountRepo) {
		super();
		this.accountRepo = accountRepo;

	}

	@Override
	public Account addCustomer(Account account) {
		// TODO Auto-generated method stub
		return accountRepo.save(account);
	}

	@Override
	public List<AccountDisplayDTO> displayAllAccounts() {
		// TODO Auto-generated method stub
		List<Account> accountList = accountRepo.findAll();
		return accountList.stream().map(account -> modelMapper.map(account, AccountDisplayDTO.class))
				.collect(Collectors.toList());
	}

	@Override
	public List<AccountDisplayDTO> findAllAccountsOfCustomer(long customer_id) throws ResourceNotFoundException {
		// TODO Auto-generated method stub
		List<Account> accountList = accountRepo.findAllAccountsOfCustomer(customer_id);
		if (accountList.isEmpty()) {
			throw new ResourceNotFoundException("Customer", "id", customer_id);
		}
		return accountList.stream().map(account -> modelMapper.map(account, AccountDisplayDTO.class))
				.collect(Collectors.toList());
	}

	@Override
	public String deleteAccount(long id) {
		// TODO Auto-generated method stub
		Optional<Account> accountToDelete = accountRepo.findById(id);
		Account accObj = accountToDelete.get();
		Customer cusobj = accObj.getCustomer();
		cusobj.getAccountList().remove(accObj);
		customerRepo.save(cusobj);
		accountRepo.deleteById(id);
		return null;
	}

	@Override
	public AccountDetailsDTO getAccountDetails(long accountId) throws ResourceNotFoundException {
		// TODO Auto-generated method stub
		Account account = accountRepo.findById(accountId)
				.orElseThrow(() -> new ResourceNotFoundException("Account", "id", accountId));

		// Map account details to DTO (Data Transfer Object)
		// return mapAccountToDTO(account);
		AccountDetailsDTO returnedobj = modelMapper.map(account, AccountDetailsDTO.class);
		returnedobj.setName(account.getCustomer().getCustomerName());
		returnedobj.setIfscCode(account.getBank().getIfscCode());
		returnedobj.setBranchName(account.getBank().getBankBranch());
		returnedobj.setBankName(account.getBank().getBankName());
		returnedobj.setBankCity(account.getBank().getBankCity());
		returnedobj.setBankState(account.getBank().getBankState());
		return returnedobj;

	}

	/*private AccountDetailsDTO mapAccountToDTO(Account account) {
		AccountDetailsDTO accountDetails = new AccountDetailsDTO();
		accountDetails.setName(account.getCustomer().getCustomerName());
		accountDetails.setAccountNumber(account.getAccountNumber());
		accountDetails.setIfscCode(account.getBank().getIfscCode());
		accountDetails.setBranchName(account.getBank().getBankBranch());
		accountDetails.setBalance(account.getAccountBalance());

		// Set additional details from the associated bank entity
		accountDetails.setBankName(account.getBank().getBankName());
		accountDetails.setBankCity(account.getBank().getBankCity());
		accountDetails.setBankState(account.getBank().getBankState());

		return accountDetails;
	}*/

	@Override
	public String addAccount(long customerid, String accountRequest) throws ResourceNotFoundException {
		// TODO Auto-generated method stub
		Optional<Customer> opt = customerRepo.findById(customerid);
		if (opt.isEmpty()) {
			throw new ResourceNotFoundException("Customer", "id", customerid);
		} else {
			Customer customer = opt.get();
			List<Account> accountList = customer.getAccountList();
			Optional<Bank> bankopt = bankRepo.findById((long) 1);
			Bank bank = bankopt.get();
			Account newAccount = new Account();
			newAccount.setAccountType(accountRequest);
			newAccount.setCustomer(customer);
			newAccount.setBank(bank);
			newAccount.setAccountStatus(AccountStatus.INACTIVE);
			newAccount.setAccountBalance(0);
			accountList.add(newAccount);
			accountRepo.save(newAccount);
			return "Account Created Successfully";
		}
	}

	@Override
	public String applyLoan(long accountnumber, String loanname, double interest, LoanDTO loan)
			throws ResourceNotFoundException {
		// TODO Auto-generated method stub
		Account accountobj = accountRepo.findById(accountnumber).get();
		if (accountobj == null) {
			throw new ResourceNotFoundException("Account", "Number", accountnumber);
		} else {

			Loan loanObj = modelMapper.map(loan, Loan.class);
			loanObj.setLoanName(loanname);
			loanObj.setInterestRate(interest);
			loanObj.setLoanStatus(LoanStatus.APPLIED);
			loanObj.setAccount(accountobj);
			List<Loan> loanList = accountobj.getLoanList();
			loanList.add(loanObj);
			accountobj.setLoanList(loanList);
			loanRepo.save(loanObj);
			return "Loan Application Submitted";
		}
	}

	@Override
	public List<LoanResponseDTO> appliedloan(long accountnumber) throws ResourceNotFoundException {
		// TODO Auto-generated method stub
		Account accountObj = accountRepo.findById(accountnumber).get();
		if (accountObj == null) {
			throw new ResourceNotFoundException("Account", "Number", accountnumber);
		} else {
			List<Loan> loanList = accountObj.getLoanList();
			return loanList.stream().map(loan -> modelMapper.map(loan, LoanResponseDTO.class))
					.collect(Collectors.toList());
		}
	}

	@Override
	public String deleteRequest(long accountnumber) throws ResourceNotFoundException {
		// TODO Auto-generated method stub
		Account obj = accountRepo.findById(accountnumber).get();
		if (obj == null) {
			throw new ResourceNotFoundException("Account", "Number", accountnumber);
		} else {
			if (obj.getAccountStatus() == AccountStatus.ACTIVE) {
				obj.setAccountStatus(AccountStatus.CLOSEREQUEST);
				accountRepo.save(obj);
				return "Close Request Submitted";
			} else {
				return "Account is Closed";
			}
		}

	}

}
