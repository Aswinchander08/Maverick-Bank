package com.hexaware.serviceimplementation;

import java.util.Optional;

import org.springframework.stereotype.Service;

import com.hexaware.entity.Bank;
import com.hexaware.repository.BankRepository;
import com.hexaware.service.BankService;
@Service
public class BankServiceImpl implements BankService {
	private BankRepository bankRepo;

	public BankServiceImpl(BankRepository bankRepo) {
		super();
		this.bankRepo = bankRepo;
	}

	@Override
	public Bank addBank(Bank bank) {
		// TODO Auto-generated method stub
		return bankRepo.save(bank);
	}

	@Override
	public Optional<Bank> findBankById(long id) {
		// TODO Auto-generated method stub
		return bankRepo.findById(id);
	}
	

}
