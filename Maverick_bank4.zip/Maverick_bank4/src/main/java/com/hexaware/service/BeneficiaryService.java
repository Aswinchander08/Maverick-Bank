package com.hexaware.service;

import java.util.List;

import com.hexaware.customexceptions.ResourceNotFoundException;
import com.hexaware.dto.BeneficiaryAddDTO;

public interface BeneficiaryService {
	public String addBeneficiary(long accountid,String bankname,String bankbranch,String bankifsccode,BeneficiaryAddDTO beneficiary) throws ResourceNotFoundException;
	public List<BeneficiaryAddDTO> getBeneficiary(long accountnumber) throws ResourceNotFoundException;

}
