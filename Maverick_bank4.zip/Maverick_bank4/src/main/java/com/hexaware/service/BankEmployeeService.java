package com.hexaware.service;

import java.util.List;

import com.hexaware.customexceptions.AccountAlreadyExistsException;
import com.hexaware.customexceptions.ResourceNotFoundException;
import com.hexaware.dto.AllTransactionDTO;
import com.hexaware.dto.BankEmployeeAddDTO;
import com.hexaware.dto.InOutDTO;
import com.hexaware.dto.LoanResponseDTO;
import com.hexaware.entity.BankEmployee;
import com.hexaware.entity.LoanOption;

public interface BankEmployeeService {
	public BankEmployeeAddDTO addEmployee(long id,BankEmployeeAddDTO emp) throws AccountAlreadyExistsException;
	public LoanOption addLoanOptionDetails(LoanOption loanoption);
	public String activateAccount(long accountnumber) throws ResourceNotFoundException;
	public String closeAccount(long accountnumber) throws ResourceNotFoundException;
	public List<AllTransactionDTO> allTransaction();
	public List<AllTransactionDTO> allTransactionOfAccount(long accountnumber) throws ResourceNotFoundException;
	public InOutDTO totalCalculation(long accountnumber) throws ResourceNotFoundException;
	public List<LoanResponseDTO> allLoanApplications();
	public String loanApproval(long loanId) throws ResourceNotFoundException;
	public List<BankEmployeeAddDTO> displayAllEmployee();
	public String deleteEmployee(long empid) throws ResourceNotFoundException;
	public String loanReject(long loanId) throws ResourceNotFoundException;
	
	

}
