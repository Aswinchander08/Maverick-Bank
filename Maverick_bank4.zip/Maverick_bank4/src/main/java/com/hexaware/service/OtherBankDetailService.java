package com.hexaware.service;

import java.util.List;

import com.hexaware.dto.OtherBankDetailsAddDTO;

public interface OtherBankDetailService {
	public OtherBankDetailsAddDTO addOtherBank(OtherBankDetailsAddDTO otherBank);
	public List<String> findByotherBankNameContaining(String name);
	public List<String> findBankBranch(String bankname);
	public String getIfsccode(String bankname,String branchname);

}
