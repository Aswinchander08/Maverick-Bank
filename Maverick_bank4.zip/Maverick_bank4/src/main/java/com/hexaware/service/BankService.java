package com.hexaware.service;

import java.util.Optional;

import com.hexaware.entity.Bank;

public interface BankService {
	public Bank addBank(Bank bank);
	public Optional<Bank> findBankById(long id);

}
