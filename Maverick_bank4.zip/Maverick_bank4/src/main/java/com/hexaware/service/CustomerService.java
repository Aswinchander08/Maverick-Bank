package com.hexaware.service;

import java.util.List;
import java.util.Optional;

import com.hexaware.customexceptions.AccountAlreadyExistsException;
import com.hexaware.customexceptions.ResourceNotFoundException;
import com.hexaware.dto.CustomerDto;
import com.hexaware.dto.LoanDTO;
import com.hexaware.entity.Customer;


public interface CustomerService {
	
	public CustomerDto createCustomer(CustomerDto c) throws AccountAlreadyExistsException;

	public CustomerDto findCustomerByid(long id)throws ResourceNotFoundException;
	public void deleteCustomerById(long id);
	public List<Customer> getAllCustomers();
	public List<Customer>findBycustomerNameContaining(String name);
	
	



}
